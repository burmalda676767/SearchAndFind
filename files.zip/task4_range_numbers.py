start = int(input("Введіть число, з якого починати: "))
end = int(input("Введіть число, на якому закінчити: "))

for number in range(start, end + 1):
    print(number, end=" ")
print()
