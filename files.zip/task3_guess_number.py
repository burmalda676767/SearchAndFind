import random

secret_number = random.randint(1, 10)
attempts = 3

print("Вгадай число від 1 до 10! У тебе є 3 спроби.")

for attempt in range(1, attempts + 1):
    guess = int(input(f"Спроба {attempt}: введи число: "))

    if guess == secret_number:
        print("Вітаю, ти вгадав число!")
        break
    elif guess > secret_number:
        print("Менше")
    else:
        print("Більше")

    if attempt == attempts and guess != secret_number:
        print(f"На жаль, спроби закінчились. Загадане число було: {secret_number}")
